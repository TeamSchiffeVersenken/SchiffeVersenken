﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace SchiffeVersenken
{
    class Spielfeld
    {
        private List<Rectangle> wasser;
        private List<Schiff> ships;
        private GameWindow window;
        private int[] maxShips;
        private int offset;

        public Spielfeld(List<Rectangle> wasser, GameWindow window, int offset)
        {
            this.offset = offset;
            this.wasser = wasser;
            maxShips = new int[] { 1, 2, 2, 3 };
            ships = new List<Schiff>();
            this.window = window;
        }
        public void feuer(Rectangle sender)
        {
            SolidColorBrush sb = sender.Fill as SolidColorBrush;
            for (int i = 0; i < ships.Count; i++)
            {
                for (int o = 0; o < ships.ElementAt(i).getLength(); o++)
                {
                    if (ships.ElementAt(i).getTeile().ElementAt(o).Equals(sender))
                    {
                        ships.ElementAt(i).hit(sender);
                        window.getMainWindow().controller.checkforWin(this);
                        return;
                    }
                    else
                    {
                        sender.Fill = Brushes.White;
                    }
                }
            }
        }

        public void Schiffsplatzierung(Rectangle sender, int orientierung, int length)
        {
            List<Rectangle> teile = new List<Rectangle>();
            int position = 0;

            foreach (Schiff s in ships)
            {
                foreach (Rectangle r in s.getTeile())
                {
                    if (r.Equals(sender))
                    {
                        return;
                    }
                }
            }
            if (orientierung == 0 && !(length==1))
            {
                position = MainWindow.getIntVonBuchstabe(sender.Name.Split('_')[0]) * offset + Convert.ToInt16(sender.Name.Split('_')[1])-offset;
                if ((length + Convert.ToInt16(sender.Name.Split('_')[1])) <= 11 + offset && !allShipsplaced(window.getSchiffTyp()))
                {
                    teile.Add(sender);
                    sender.Fill = Brushes.Gray;
                    for (int i = 0; i < (length -1); i++)
                    {
                        SolidColorBrush sb = wasser.ElementAt(i + position).Fill as SolidColorBrush;
                        if (!sb.Color.Equals(Colors.Gray))
                        {
                            teile.Add(wasser.ElementAt(i + position));
                            wasser.ElementAt(i + position).Fill = Brushes.Gray;
                        }
                        else
                        {
                            foreach (Rectangle r in teile)
                            {
                                r.Fill = Brushes.LightBlue;
                            }
                            teile.Clear();
                            return;
                        }
                    }
                    ships.Add(new Schiff(teile));
                }
            }
            else if (orientierung == 1 && !(length == 1))
            {
                position= MainWindow.getIntVonBuchstabe(sender.Name.Split('_')[0]) * offset + Convert.ToInt16(sender.Name.Split('_')[1]) - offset;
                if ((length * (10 + offset) + (MainWindow.getIntVonBuchstabe(sender.Name.Split('_')[0]) * (10 + offset))) <= 112 * offset && !allShipsplaced(window.getSchiffTyp()))
                { 
                    for (int i = -1; i < length * (offset - 1); i += offset)

                    {
                        SolidColorBrush sb = wasser.ElementAt(i + position).Fill as SolidColorBrush;
                        if(!sb.Color.Equals(Colors.Gray))
                        {
                            teile.Add(wasser.ElementAt(i + position));
                            wasser.ElementAt(i + position).Fill = Brushes.Gray;
                        }
                        else
                        {
                            foreach(Rectangle element in  teile)
                            {
                                element.Fill = Brushes.LightBlue;
                            }
                            teile.Clear();
                            return;
                        }
                        ships.Add(new Schiff(teile));
                    }                
                }
            }
            else if (length == 1)
            {
                SolidColorBrush sb = sender.Fill as SolidColorBrush;
                if (!sb.Color.Equals(Colors.Gray));
                {
                    sender.Fill = Brushes.Gray;
                    teile.Add(sender);
                    ships.Add(new Schiff(teile));
                }
            }
        }

        private bool allShipsplaced(int type)
        {
            int shipsOfType = 0;
            foreach (Schiff ship in ships)
            {
                if (ship.GetType().Equals(type))
                {
                    shipsOfType++;
                }
                if (shipsOfType >= maxShips[type])
                {
                    MessageBox.Show("Maximale Anzahl dieses Schifftypes wurde erreicht! ");
                    return true;
                }
            }
            return false;
        }

        public bool AlleSchiffePlatziert()
        {
            if (ships.Count == getMaxShips())
            {
                foreach (Schiff ship in ships)
                {
                    foreach (Rectangle part in ship.getTeile())
                    {
                        part.Fill = Brushes.LightBlue;
                    }
                }
                return true;
            }
            return false;
        }


        public List<Schiff> getShips()
        {
            return this.ships;
        }

        public int getMaxShips()
        {
            return this.maxShips.Sum();
        }
      
    }
}