﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows;

namespace SchiffeVersenken
{
    class SpielfeldKontrolle
    {
        private bool[] spielerBereit;
        private bool spiellaeuft;
        private Spielfeld sf1, sf2;
        private bool zugSpieler1;

        public SpielfeldKontrolle(Spielfeld sf1, Spielfeld sf2)
        {
            this.sf1 = sf2;
            this.sf2 = sf2;
            spielerBereit = new bool[] { false, false };
            spiellaeuft = false;
            zugSpieler1 = true;
        }
        private void wechsleSpieler()
        {
            zugSpieler1 = !zugSpieler1;
        }
        public void Fire(Rectangle sender, Spielfeld sf)
        {
            SolidColorBrush sb = sender.Fill as SolidColorBrush;
            if (zugSpieler1 && sf.Equals(sf1) && sb.Equals(Colors.LightBlue))
                sf1.feuer(sender);
            else if (!zugSpieler1 && sf.Equals(sf2) && sb.Equals(Colors.LightBlue))
                sf2.feuer(sender);
            else
                return;
            wechsleSpieler();
        }
        public bool Spieler1()
        {
            return this.zugSpieler1;
        }
        public void setGestartet(Spielfeld sf)
        {
            if (sf.Equals(sf1))
                spielerBereit[0] = true;
            if (sf.Equals(sf2))
                spielerBereit[1] = true;

            if (spielerBereit[0] && spielerBereit[1])
                spiellaeuft = true;
        }
        public bool checkforWin(Spielfeld sf)
        {
            List<Schiff> ships = sf.getShips();
            int shipCount = sf.getMaxShips();
            foreach(Schiff ship in ships)
            {
                if (ship.isSinking())
                    shipCount--;
            }   
        }
        public bool istGestartet()
        {
            return this.spiellaeuft;
        }
        public bool[] getBereiteSpieler()
        {
            return this.spielerBereit;
        }
    }
}
