﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace SchiffeVersenken
{
    public partial class MainWindow : Window
    {
        private static string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private bool gameOpen, gameStarted, Spieler1;
        public SpielfeldKontrolle controller;

        public MainWindow() 
        {
            InitializeComponent();
            gameStarted = false;
            Spieler1 = true;
        }
        public void checkforStart()
        {
            if (controller.getBereiteSpieler()[0]&&controller.getBereiteSpieler()[1])
            {
                MessageBox.Show("Das Spiel startet");
            }
        }

        public void starteSpiel(object sender, RoutedEventArgs e)
        {
            if(!gameOpen)
            {
                gameOpen = true;
                GameWindow w1 = new GameWindow(this, 10);
                w1.Show();
                w1.Title = "Spieler 1";

                GameWindow w2 = new GameWindow(this, 10);
                w2.Show();
                w2.Title = "Spieler2";

                controller = new SpielfeldKontrolle(w1.getSpielfeld(),w2.getSpielfeld());
            }
        }
        public static string getBuchstabeVonInt(int i)
        {
            return alphabet.ElementAt(i).ToString();
        }
        public static int getIntVonBuchstabe(string s)
        {
            return alphabet.IndexOf(s) + 1;
        }
    }
}
