﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows;
namespace Schiffe_Versenken
{
   public class Schiff
    {
        private List<Rectangle> parts;
        private List<Rectangle> trefferpunkte;

        public Schiff(List<Rectangle>parts)
        {
            this.parts = parts;
            trefferpunkte = new List<Rectangle>();
        }
        public void hit(Rectangle sender)
        {
            if(!trefferpunkte.Contains(sender))
            {
                sender.Fill = Brushes.Red;
                trefferpunkte.Add(sender);

                if(trefferpunkte.Count==parts.Count)
                {
                    string type = "";

                    switch(getType())
                    {
                        case 0:
                            type = "Schlachtschiff";
                            break;

                        case 1:
                            type = "Kreuzer";
                            break;

                        case 2:
                            type = "Zerstörer";
                            break;

                        case 3:
                            type = "U-Boot";
                            break;
                    }
                    MessageBox.Show("Ein " + type + " wurde versenkt !");
                }
            }
        }

        public List<Rectangle> getHitParts()
        {
            return this.trefferpunkte;
        } 

        public List<Rectangle> getParts()
        {
            return this.parts;
        }

        public int getType()
        {
            int length = parts.Count;

            switch(length)
            {
                case 5:
                    return 0;
                case 3:
                    return 1;
                case 2:
                    return 2;
                case 1:
                    return 3;
                default:
                    return 4;
            }
        }
        public bool isSinking()
        {
            if (trefferpunkte.Count == parts.Count)
                return true;
            return false;
        }

        public int getLength()
        {
            return this.parts.Count;
        }
    }
}
