﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows;

namespace SchiffeVersenken
{
    class Spielfeld
    {
        private List<Rectangle> water;
        private List<Schiff> ships;

        private int[] maxShips;
        private double offset;

        public Spielfeld(List<Rectangle> water, double offset)
        {
            this.offset = offset;
            this.water = water;
            maxShips = new int[] { 1, 2, 2, 3 };
            ships = new List<Schiff>();
        }
        public void fire(Rectangle sender)
        {

        }
        public void placeShip(Rectangle sender, int orientation, int length)
        {

        }
        private bool allShipsPlaced(int type)
        {
            int shipsOfType = 0;
            foreach (Schiff ship in ships)
            {
                if (ship.GetType().Equals(type))
                {
                    shipsOfType++;
                }
                if (shipsOfType >= maxShips[type])
                {
                    MessageBox.Show("Du hast die maximale Anzahl dieses Schifftys bereits gesetzt!");
                    return true;
                }
            }
            return false;
        }
        public List<Schiff> getShips()
        {
            return this.ships;
        }
        public int getMaxShips()
        {
            return this.maxShips.Sum();
        }
        

    }
}
