﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows;

namespace Schiffe_Versenken
{
   public class SpielfeldController
    {
        private bool[] readyPlayer;
        private bool gameStarted;
        private Spielfeld sf1, sf2;
        private bool playerOnesTurn;

        public SpielfeldController(Spielfeld sf1, Spielfeld sf2)
        {
            this.sf1 = sf1;
            this.sf2 = sf2;
            readyPlayer = new bool[] { false, false };
            gameStarted = false;
            playerOnesTurn = true;
        }

        private void switchPlayer()
        {
            playerOnesTurn =! playerOnesTurn;
        }

        public void fire(Rectangle sender, Spielfeld sf)
        {
            SolidColorBrush sb = sender.Fill as SolidColorBrush;
            if (playerOnesTurn && sf.Equals(sf1) && sb.Color.Equals(Colors.LightBlue))
                sf.fire(sender);                                       // Hier wird geschaut ob der Spieler getroffen hat oder nicht.und wenn beide nicht treffen beginnt der erste wieder
            else if (!playerOnesTurn && sf.Equals(sf2) && sb.Color.Equals(Colors.LightBlue))
                sf2.fire(sender);           
            else
                return;
            switchPlayer();            
        }

        public bool playerOne()
        {
            return this.playerOnesTurn;
        }

        public void setStarted(Spielfeld sf)
        {
            if (sf.Equals(sf1))
                readyPlayer[0] = true;
            if (sf.Equals(sf2))
                readyPlayer[1] = true;              //Wenn beide Spieler bereit sind wird das game gestarted sonst kann das Spiel nicht beginnen
            if (readyPlayer[0] && readyPlayer[1])
                gameStarted = true;
        }

        public bool checkForWin(Spielfeld sf)
        {
            List<Schiff> ships = sf.getShips();
            int shipCount = sf.getMaxShips();
            foreach (Schiff ship in ships)
            {
                if (ship.isSinking())
                    shipCount--;
            }

            if (shipCount == 0)
                return true;
            return false;           
        }

        public bool isStarted()
        {
            return this.gameStarted;
        }

        public bool [] getReadyPlayers()
        {
            return this.readyPlayer;
        }
    }
}
